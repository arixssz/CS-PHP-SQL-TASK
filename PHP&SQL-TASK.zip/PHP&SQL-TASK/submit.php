<?php
// Include the database configuration file
require_once 'db_config.php';

$message = ""; // Initialize the message variable

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $feedback = htmlspecialchars($_POST['feedback']);

    // Ensure the connection is open before executing queries
    if ($conn && $conn->connect_error == null) {
        // Check for duplicate feedback
        $check_sql = "SELECT * FROM feedback WHERE name = ? AND email = ? AND feedback = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("sss", $name, $email, $feedback);
        $check_stmt->execute();
        $result = $check_stmt->get_result();

        if ($result->num_rows > 0) {
            // Feedback already exists
            $message = "Your feedback has already been submitted.";
        } else {
            // Insert new feedback into the database
            $sql = "INSERT INTO feedback (name, email, feedback) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);

            if ($stmt) {
                $stmt->bind_param("sss", $name, $email, $feedback);

                if ($stmt->execute()) {
                    $message = "Thank you, <b>$name</b>, for your feedback!";
                } else {
                    $message = "Error: " . $stmt->error;
                }

                $stmt->close(); // Close the prepared statement
            } else {
                $message = "Error preparing query: " . $conn->error;
            }
        }

        $check_stmt->close(); // Close the duplicate check statement
    } else {
        $message = "Database connection error: " . $conn->connect_error;
    }

    // Close the database connection after all operations are complete
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submission Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .result-container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            text-align: center;
            width: 300px;
        }
        .result-container h2 {
            color: #007BFF;
            margin-bottom: 15px;
        }
        .result-container p {
            font-size: 16px;
            color: #333;
            margin-bottom: 20px;
        }
        .result-container a {
            text-decoration: none;
            color: #fff;
            background-color: #007BFF;
            padding: 10px 20px;
            border-radius: 5px;
            display: inline-block;
        }
        .result-container a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="result-container">
        <h2>Submission Status</h2>
        <p><?php echo $message; ?></p>
        <a href="index.html">Go Back</a>
    </div>
</body>
</html>
